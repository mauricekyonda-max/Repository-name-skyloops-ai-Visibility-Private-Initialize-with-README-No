-- SYATU PRIMARY SCHOOL: run this entire script in Supabase SQL Editor.
-- It creates private-by-default tables and a private Storage bucket.
-- Do not add a service_role key to the website.

create extension if not exists pgcrypto;

do $$ begin
  create type public.school_role as enum ('admin','safeguarding_team','teacher','sponsor','viewer');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role public.school_role not null default 'viewer',
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  body text not null check (char_length(body) between 1 and 3000),
  is_published boolean not null default false,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
alter table public.announcements enable row level security;

create table if not exists public.school_events (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  description text default '',
  event_date timestamptz not null,
  is_published boolean not null default false,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
alter table public.school_events enable row level security;

create table if not exists public.media_assets (
  id uuid primary key default gen_random_uuid(),
  storage_path text not null unique,
  caption text default '',
  mime_type text not null,
  uploaded_by uuid not null references auth.users(id),
  approval_status text not null default 'pending' check (approval_status in ('pending','approved','rejected')),
  consent_reference text,
  created_at timestamptz not null default now()
);
alter table public.media_assets enable row level security;

create table if not exists public.sponsor_assignments (
  id uuid primary key default gen_random_uuid(),
  sponsor_user_id uuid not null references auth.users(id),
  pupil_code text not null,
  assigned_by uuid not null references auth.users(id),
  status text not null default 'active' check (status in ('active','paused','ended')),
  created_at timestamptz not null default now(),
  unique(sponsor_user_id,pupil_code)
);
alter table public.sponsor_assignments enable row level security;

create table if not exists public.moderated_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id),
  recipient_id uuid references auth.users(id),
  pupil_code text,
  message_body text not null check (char_length(message_body) between 1 and 2000),
  moderation_status text not null default 'pending' check (moderation_status in ('pending','approved','rejected')),
  moderated_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
alter table public.moderated_messages enable row level security;

create table if not exists public.video_sessions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  meeting_provider text,
  meeting_reference text,
  assigned_sponsor_user_id uuid references auth.users(id),
  pupil_code text,
  status text not null default 'scheduled' check (status in ('scheduled','cancelled','completed')),
  created_by uuid not null references auth.users(id),
  check (ends_at > starts_at)
);
alter table public.video_sessions enable row level security;

create or replace function public.current_school_role()
returns public.school_role language sql stable security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid()
$$;
revoke all on function public.current_school_role() from public;
grant execute on function public.current_school_role() to authenticated;

-- Profile rows are visible only to the account owner and authorized administrators.
drop policy if exists "profile self read" on public.profiles;
create policy "profile self read" on public.profiles for select to authenticated
using (id = auth.uid() or public.current_school_role() = 'admin');
drop policy if exists "admin profile manage" on public.profiles;
create policy "admin profile manage" on public.profiles for all to authenticated
using (public.current_school_role() = 'admin')
with check (public.current_school_role() = 'admin');

-- Public can read published notices/events; only authorized school staff can manage them.
drop policy if exists "public published announcements" on public.announcements;
create policy "public published announcements" on public.announcements for select to anon, authenticated using (is_published = true);
drop policy if exists "staff manage announcements" on public.announcements;
create policy "staff manage announcements" on public.announcements for all to authenticated
using (public.current_school_role() in ('admin','safeguarding_team'))
with check (public.current_school_role() in ('admin','safeguarding_team'));
drop policy if exists "public published events" on public.school_events;
create policy "public published events" on public.school_events for select to anon, authenticated using (is_published = true);
drop policy if exists "staff manage events" on public.school_events;
create policy "staff manage events" on public.school_events for all to authenticated
using (public.current_school_role() in ('admin','safeguarding_team'))
with check (public.current_school_role() in ('admin','safeguarding_team'));

-- Media metadata is never public. Only authorized staff can read/manage it in this starter.
drop policy if exists "staff manage media metadata" on public.media_assets;
create policy "staff manage media metadata" on public.media_assets for all to authenticated
using (public.current_school_role() in ('admin','safeguarding_team'))
with check (public.current_school_role() in ('admin','safeguarding_team'));

-- Sponsor assignments and private messages are restricted to safeguarding staff/admin for now.
-- Sponsor-facing access should be added only after the school approves a documented safeguarding workflow.
drop policy if exists "staff manage sponsor assignments" on public.sponsor_assignments;
create policy "staff manage sponsor assignments" on public.sponsor_assignments for all to authenticated
using (public.current_school_role() in ('admin','safeguarding_team'))
with check (public.current_school_role() in ('admin','safeguarding_team'));
drop policy if exists "staff manage moderated messages" on public.moderated_messages;
create policy "staff manage moderated messages" on public.moderated_messages for all to authenticated
using (public.current_school_role() in ('admin','safeguarding_team'))
with check (public.current_school_role() in ('admin','safeguarding_team'));
drop policy if exists "staff manage video sessions" on public.video_sessions;
create policy "staff manage video sessions" on public.video_sessions for all to authenticated
using (public.current_school_role() in ('admin','safeguarding_team'))
with check (public.current_school_role() in ('admin','safeguarding_team'));

-- Create a private bucket. Private objects have no public URL.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('school-private','school-private',false,52428800,
  array['image/jpeg','image/png','image/webp','video/mp4','video/webm'])
on conflict (id) do update set public=false, file_size_limit=52428800,
  allowed_mime_types=array['image/jpeg','image/png','image/webp','video/mp4','video/webm'];

drop policy if exists "school staff upload private media" on storage.objects;
create policy "school staff upload private media" on storage.objects for insert to authenticated
with check (bucket_id='school-private' and public.current_school_role() in ('admin','safeguarding_team'));
drop policy if exists "school staff read private media" on storage.objects;
create policy "school staff read private media" on storage.objects for select to authenticated
using (bucket_id='school-private' and public.current_school_role() in ('admin','safeguarding_team'));
drop policy if exists "school staff delete private media" on storage.objects;
create policy "school staff delete private media" on storage.objects for delete to authenticated
using (bucket_id='school-private' and public.current_school_role() in ('admin','safeguarding_team'));

-- Automatically create a least-privilege profile for each new auth user.
create or replace function public.handle_new_school_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id,display_name,role)
  values(new.id, coalesce(new.raw_user_meta_data->>'display_name',''), 'viewer')
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_school_profile on auth.users;
create trigger on_auth_user_created_school_profile
after insert on auth.users
for each row execute procedure public.handle_new_school_user();

-- IMPORTANT: after creating the first staff account in Authentication > Users,
-- copy its UUID and run this separately, replacing the UUID:
-- update public.profiles set role='admin' where id='PASTE-USER-UUID-HERE';
-- Do not allow public sign-ups. Admin should invite staff accounts.

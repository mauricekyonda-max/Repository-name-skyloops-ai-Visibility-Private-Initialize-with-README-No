SYATU PRIMARY SCHOOL WEBSITE — ANDROID QUICK START
=================================================

WHAT IS INCLUDED
- index.html: school website pages and staff sign-in
- styles.css: responsive design for phones and computers
- app.js: Supabase connection, public announcements/events, staff sign-in,
  announcement publishing, protected media upload
- supabase_setup.sql: database tables, Row Level Security and private storage policies

IMPORTANT SAFETY RULES
1. Never place the Supabase service_role/secret key in app.js or any browser file.
2. Use only the Project URL and publishable/anon public key in app.js.
3. Do not upload identifiable pupil photos/videos until documented parent/guardian
   consent and school safeguarding approval are in place.
4. This starter keeps media private and marks uploads pending. It does not publish
   student media or expose private storage URLs.
5. Sponsor-to-pupil chat/video is NOT enabled for direct unsupervised use. The
   database includes restricted records for a school-moderated workflow. Have the
   school safeguarding lead approve procedures before adding sponsor access.
6. Payment integrations are placeholders. Verify the school's official M-Pesa
   recipient and international donation provider account before accepting money.

STEP 1 — EXTRACT THE ZIP ON ANDROID
- Download and open the ZIP in Files / File Manager.
- Choose Extract.
- You should see this folder with the four files listed above.

STEP 2 — RUN THE DATABASE SQL
- Open Chrome and sign in at https://supabase.com/dashboard
- Open the Syatu Primary School project.
- Open SQL Editor, choose New query.
- Open supabase_setup.sql from the extracted ZIP, select and copy all its text.
- Paste into the SQL Editor and press Run.
- Check for a success message. If an error appears, stop and share the exact error;
  do not repeatedly run random SQL changes.

STEP 3 — CREATE THE FIRST ADMIN ACCOUNT
- In Supabase open Authentication > Users.
- Create/invite the school's official administrator account using an email controlled
  by the school. Set a strong unique password.
- Copy that user's UUID from the Users page.
- Return to SQL Editor and run this one statement, replacing the placeholder:
  update public.profiles set role='admin' where id='PASTE-USER-UUID-HERE';
- Confirm exactly one row was updated.
- In Authentication settings, disable public sign-ups. Use admin invitations for staff.
- Never make a sponsor or public visitor an admin.

STEP 4 — GET THE SAFE BROWSER CONNECTION VALUES
- In Supabase Project Settings > API (or API Keys), copy the Project URL and the
  publishable key (or legacy anon public key).
- Do NOT copy the service_role key or secret key.
- Open app.js in a text editor and replace only:
  PASTE_YOUR_SUPABASE_PROJECT_URL_HERE
  PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE
- Save app.js.

STEP 5 — UPLOAD THE WEBSITE TO GITHUB FROM ANDROID
- Open https://github.com and sign in.
- Open the private Syatu repository you already created.
- Choose Add file > Upload files.
- Upload index.html, styles.css and app.js from the extracted folder.
- Upload README_ANDROID.txt too if desired. The SQL file can stay in your private
  repository; it contains no secrets.
- Commit the changes to the main branch.
- For a simple live website, connect the repository to a static host such as
  Cloudflare Pages or Netlify. Choose the repository, production branch main,
  build command blank, and output directory / (root). Use HTTPS.
- If your host requires a public repository, do not make the repository public just
  to deploy; choose a host that supports private GitHub repositories.

STEP 6 — TEST SAFELY
- Open the deployed HTTPS website.
- Confirm homepage and public pages load.
- Sign in with the admin account.
- Publish a test announcement with no pupil personal information.
- Test upload with a non-identifying sample image first. Confirm it is marked pending.
- Sign out and confirm staff tools disappear.
- Test the site in a private/incognito browser: no private media or portal data should
  be visible.

WHAT THIS FIRST VERSION DOES NOT YET DO
- It does not provide a full sponsor dashboard, pupil records, direct messaging,
  video calling, live streaming, M-Pesa checkout or international payment checkout.
- These need additional reviewed workflows, payment-provider approval, moderation,
  access testing and (for live streaming) a separate streaming service.
- Do not put pupils' full names, admission numbers, home addresses, medical/disability
  details or private documents in public announcements.

TROUBLESHOOTING
- "Invalid API key": check that you used the publishable/anon key, not service_role.
- "Your account has no approved school role": run the admin role SQL using the exact
  Auth user UUID; then sign out and sign in again.
- Upload denied: confirm the SQL ran, your profile role is admin or safeguarding_team,
  and the bucket is named school-private.
- Never send passwords or secret keys in chat or commit them to GitHub.

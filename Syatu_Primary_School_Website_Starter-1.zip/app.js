// Public browser key only: never put a Supabase service_role key in this file.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const client = configured ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
const $ = (id) => document.getElementById(id);
$("menuButton").addEventListener("click", () => $("mainNav").classList.toggle("open"));
document.querySelectorAll("#mainNav a").forEach(a => a.addEventListener("click", () => $("mainNav").classList.remove("open")));
if (configured) {
  $("configNotice").hidden = true;
  loadPublicContent();
  client.auth.getSession().then(({data}) => { if (data.session) showPortal(data.session.user); });
}
async function loadPublicContent() {
  const [{data: news,error:nErr},{data: events,error:eErr}] = await Promise.all([
    client.from("announcements").select("id,title,body,created_at").eq("is_published",true).order("created_at",{ascending:false}).limit(8),
    client.from("school_events").select("id,title,description,event_date").eq("is_published",true).order("event_date",{ascending:true}).limit(8)
  ]);
  if (!nErr && news?.length) $("announcements").innerHTML = news.map(x=>`<article class="announcement"><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.body)}</p></article>`).join("");
  if (!eErr && events?.length) $("eventsList").innerHTML = events.map(x=>`<article class="announcement"><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.description||"")}</p><small>${new Date(x.event_date).toLocaleString()}</small></article>`).join("");
}
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("loginForm").addEventListener("submit", async e=>{
  e.preventDefault(); if(!client){$("loginStatus").textContent="Connect Supabase first by adding your project URL and public anon/publishable key in app.js.";return;}
  $("loginStatus").textContent="Signing in…";
  const {data,error}=await client.auth.signInWithPassword({email:$("email").value.trim(),password:$("password").value});
  if(error){$("loginStatus").textContent=error.message;return;} $("loginStatus").textContent=""; await showPortal(data.user);
});
async function showPortal(user){
  $("loginForm").hidden=true;$("portalPanel").hidden=false;$("signedInAs").textContent=`Signed in: ${user.email}`;
  const {data:profile,error}=await client.from("profiles").select("role,display_name").eq("id",user.id).single();
  if(error||!profile){$("roleNotice").textContent="Your account has no approved school role. Contact the school administrator.";return;}
  $("roleNotice").textContent=`Access role: ${profile.role}. Private pupil media is not displayed on this public page.`;
  if(["admin","safeguarding_team"].includes(profile.role)) $("staffTools").hidden=false;
}
$("logoutButton").addEventListener("click",async()=>{await client.auth.signOut();$("portalPanel").hidden=true;$("loginForm").hidden=false;$("staffTools").hidden=true;});
$("announcementForm").addEventListener("submit",async e=>{
  e.preventDefault();const status=$("announcementStatus");status.textContent="Publishing…";
  const {data:{user}}=await client.auth.getUser();
  const {error}=await client.from("announcements").insert({title:$("announcementTitle").value.trim(),body:$("announcementBody").value.trim(),created_by:user.id,is_published:true});
  status.textContent=error?error.message:"Announcement published.";if(!error){e.target.reset();loadPublicContent();}
});
$("uploadForm").addEventListener("submit",async e=>{
  e.preventDefault();const status=$("uploadStatus");const file=$("mediaFile").files[0];
  if(!file||!$("mediaConsent").checked){status.textContent="Select a file and confirm documented consent and safeguarding approval.";return;}
  const allowed=["image/jpeg","image/png","image/webp","video/mp4","video/webm"];
  if(!allowed.includes(file.type)){status.textContent="Only JPG, PNG, WebP, MP4 or WebM files are allowed.";return;}
  const max=file.type.startsWith("video/")?50*1024*1024:8*1024*1024;
  if(file.size>max){status.textContent="File is too large. Maximum: 8 MB for images and 50 MB for videos.";return;}
  const {data:{user}}=await client.auth.getUser();const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");const path=`${user.id}/${crypto.randomUUID()}-${safeName}`;
  status.textContent="Uploading to private storage…";
  const {error:upErr}=await client.storage.from("school-private").upload(path,file,{contentType:file.type,upsert:false});
  if(upErr){status.textContent=upErr.message;return;}
  const {error:dbErr}=await client.from("media_assets").insert({storage_path:path,caption:$("mediaCaption").value.trim(),mime_type:file.type,uploaded_by:user.id,approval_status:"pending"});
  if(dbErr){status.textContent=`File uploaded but its record failed: ${dbErr.message}. Contact the administrator; do not share the file URL.`;return;}
  status.textContent="Uploaded privately and marked pending review. It is not public.";e.target.reset();
});